package com.example.myapplication;// MainActivity.java
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

	// 声明所有控件（与XML中的id严格对应）
	private EditText etName, etPassword;
	private RadioButton radioButtonMale, radioButtonFemale;
	private Switch switchHideGender;
	private CheckBox cbSport, cbMusic, cbArt, cbReading;
	private Spinner spCity;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// 初始化控件绑定
		initViews();

		// 设置Switch监听器控制性别选项显隐
		setupGenderVisibility();

		// 配置提交按钮点击事件
		setupSubmitButton();
	}

	private void initViews() {
		etName = findViewById(R.id.etName);
		etPassword = findViewById(R.id.etPassword);
		radioButtonMale = findViewById(R.id.radioButton);
		radioButtonFemale = findViewById(R.id.radioButton2);
		switchHideGender = findViewById(R.id.switch1);
		cbSport = findViewById(R.id.checkBox);
		cbMusic = findViewById(R.id.checkBox2);
		cbArt = findViewById(R.id.checkBox3);
		cbReading = findViewById(R.id.checkBox4);
		spCity = findViewById(R.id.spCity);
	}

	private void setupGenderVisibility() {
		// 获取RadioButton父容器（需在XML中添加RadioGroup）
		RadioGroup radioGroup = findViewById(R.id.radioGroup);

		switchHideGender.setOnCheckedChangeListener((buttonView, isChecked) -> {
			// 切换性别选项可见性
			radioGroup.setVisibility(isChecked ? View.GONE : View.VISIBLE);
			// 隐藏时清空选择
			if (isChecked) radioGroup.clearCheck();
		});
	}

	private void setupSubmitButton() {
		findViewById(R.id.btnSubmit).setOnClickListener(v -> {
			// 执行输入验证
			if (validateInput()) {
				showRegistrationInfo();
			}
		});
	}

	private boolean validateInput() {
		// 简单非空验证
		if (etName.getText().toString().trim().isEmpty()) {
			showToast("用户名不能为空");
			return false;
		}
		return true;
	}

	private void showRegistrationInfo() {
		// 构建显示内容
		String displayText = createDisplayText();

		// 弹出结果对话框
		new AlertDialog.Builder(this)
				.setTitle("注册信息")
				.setMessage(displayText)
				.setPositiveButton("确定", null)
				.show();
	}

	private String createDisplayText() {
		// 获取基础信息
		String username = etName.getText().toString();
		String city = spCity.getSelectedItem().toString();

		// 构建性别称呼
		String gender = getGenderTitle();

		// 处理兴趣爱好
		String hobbies = getSelectedHobbies();

		return String.format(
				"%s%s您好！\n所在城市：%s\n兴趣爱好：%s",
				username,
				gender,
				city,
				hobbies
		);
	}

	private String getGenderTitle() {
		if (switchHideGender.isChecked()) {
			return "";
		}
		if (radioButtonMale.isChecked()) {
			return "先生";
		}
		if (radioButtonFemale.isChecked()) {
			return "女士";
		}
		return "";
	}

	private String getSelectedHobbies() {
		StringBuilder sb = new StringBuilder();
		if (cbSport.isChecked()) sb.append("体育，");
		if (cbMusic.isChecked()) sb.append("音乐，");
		if (cbArt.isChecked()) sb.append("绘画，");
		if (cbReading.isChecked()) sb.append("阅读，");

		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length() - 1); // 移除末尾逗号
		} else {
			sb.append("无");
		}
		return sb.toString();
	}

	private void showToast(String message) {
		Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
	}
}